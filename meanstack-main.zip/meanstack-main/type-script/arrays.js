var studentNames;
var rollNumbers;
studentNames = ['Shiva', 'John', 'David', 'Sasi'];
rollNumbers = [1, 2, 3, 4];
console.log(studentNames);
console.log(rollNumbers);
