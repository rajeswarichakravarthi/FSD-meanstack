let personName: string;
let personAge: number;
let isQualified: boolean;

personName = 'Shiva';
personAge = 23;
isQualified = true;
